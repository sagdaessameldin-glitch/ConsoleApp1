using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearning.Models;

namespace OnlineLearning.Configurations;

public class CourseConfiguration : IEntityTypeConfiguration<Course>
{
    public void Configure(EntityTypeBuilder<Course> builder)
    {
        builder.HasKey(c => c.Id);

        builder.Property(c => c.Title).IsRequired().HasMaxLength(200);
        builder.Property(c => c.Description).HasMaxLength(1000);
        builder.Property(c => c.Price).IsRequired().HasPrecision(10, 2);

        // Store the enum as readable text
        builder.Property(c => c.Level).IsRequired().HasConversion<string>().HasMaxLength(20);

        builder.Property(c => c.IsPublished).IsRequired().HasDefaultValue(false);
        builder.Property(c => c.PublishedAt);   // nullable: empty until published

        builder.HasOne(c => c.Instructor)
               .WithMany(i => i.Courses)
               .HasForeignKey(c => c.InstructorId)
               .OnDelete(DeleteBehavior.Restrict);

        builder.HasOne(c => c.Category)
               .WithMany(cat => cat.Courses)
               .HasForeignKey(c => c.CategoryId)
               .OnDelete(DeleteBehavior.Restrict);

        if (SeedSwitch.Skip) return;

        builder.HasData(
            new Course { Id = 1, Title = "C# Fundamentals", Description = "Learn C# from zero.", Price = 49.99m, Level = CourseLevel.Beginner, IsPublished = true, PublishedAt = new DateTime(2023, 1, 15), InstructorId = 1, CategoryId = 1 },
            new Course { Id = 2, Title = "ASP.NET Core Web API", Description = "Build REST APIs.", Price = 89.99m, Level = CourseLevel.Intermediate, IsPublished = true, PublishedAt = new DateTime(2023, 4, 1), InstructorId = 1, CategoryId = 3 },
            new Course { Id = 3, Title = "EF Core Deep Dive", Description = "Advanced EF Core topics.", Price = 129.99m, Level = CourseLevel.Advanced, IsPublished = true, PublishedAt = new DateTime(2023, 8, 10), InstructorId = 2, CategoryId = 2 },
            new Course { Id = 4, Title = "React Basics", Description = "Intro to React.", Price = 59.99m, Level = CourseLevel.Beginner, IsPublished = false, PublishedAt = null, InstructorId = 2, CategoryId = 4 },
            new Course { Id = 5, Title = "Advanced UI Patterns", Description = null, Price = 99.00m, Level = CourseLevel.Advanced, IsPublished = false, PublishedAt = null, InstructorId = 3, CategoryId = 6 },
            new Course { Id = 6, Title = "Design Thinking", Description = "Creative problem solving.", Price = 39.50m, Level = CourseLevel.Intermediate, IsPublished = true, PublishedAt = new DateTime(2024, 2, 20), InstructorId = 3, CategoryId = 5 }
        );
    }
}

namespace OnlineLearning.Configurations;

/// <summary>
/// Design-time helper. Setting the environment variable SKIP_SEED=1 makes the model
/// ignore HasData, which lets us create the "InitialCreate" migration WITHOUT seed data
/// and then a separate "SeedData" migration WITH seed data (see README).
/// </summary>
internal static class SeedSwitch
{
    public static bool Skip => Environment.GetEnvironmentVariable("SKIP_SEED") == "1";
}

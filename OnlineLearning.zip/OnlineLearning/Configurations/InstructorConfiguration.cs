using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearning.Models;

namespace OnlineLearning.Configurations;

public class InstructorConfiguration : IEntityTypeConfiguration<Instructor>
{
    public void Configure(EntityTypeBuilder<Instructor> builder)
    {
        builder.HasKey(i => i.Id);

        builder.Property(i => i.FullName).IsRequired().HasMaxLength(100);
        builder.Property(i => i.Email).IsRequired().HasMaxLength(150);
        builder.Property(i => i.Bio).HasMaxLength(500);
        builder.Property(i => i.JoinedAt).IsRequired();

        builder.HasIndex(i => i.Email).IsUnique();

        // One instructor -> many courses. Deleting an instructor that has courses is not allowed.
        builder.HasMany(i => i.Courses)
               .WithOne(c => c.Instructor)
               .HasForeignKey(c => c.InstructorId)
               .OnDelete(DeleteBehavior.Restrict);

        if (SeedSwitch.Skip) return;

        builder.HasData(
            new Instructor { Id = 1, FullName = "Ahmed Hassan", Email = "ahmed.hassan@learn.com", Bio = "Senior .NET developer and trainer.", JoinedAt = new DateTime(2022, 1, 10) },
            new Instructor { Id = 2, FullName = "Sara Mahmoud", Email = "sara.mahmoud@learn.com", Bio = "Full-stack engineer.", JoinedAt = new DateTime(2022, 6, 5) },
            new Instructor { Id = 3, FullName = "Omar Khaled", Email = "omar.khaled@learn.com", Bio = null, JoinedAt = new DateTime(2023, 3, 20) }
        );
    }
}

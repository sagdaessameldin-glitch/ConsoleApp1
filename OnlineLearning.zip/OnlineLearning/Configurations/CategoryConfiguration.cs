using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearning.Models;

namespace OnlineLearning.Configurations;

public class CategoryConfiguration : IEntityTypeConfiguration<Category>
{
    public void Configure(EntityTypeBuilder<Category> builder)
    {
        builder.HasKey(c => c.Id);

        builder.Property(c => c.Name).IsRequired().HasMaxLength(100);
        builder.Property(c => c.Description).HasMaxLength(500);

        // Self-referencing relationship.
        // Restrict => a parent that still has sub-categories cannot be deleted.
        builder.HasOne(c => c.ParentCategory)
               .WithMany(c => c.SubCategories)
               .HasForeignKey(c => c.ParentCategoryId)
               .OnDelete(DeleteBehavior.Restrict);

        // One category -> many courses (every course has exactly one category)
        builder.HasMany(c => c.Courses)
               .WithOne(c => c.Category)
               .HasForeignKey(c => c.CategoryId)
               .OnDelete(DeleteBehavior.Restrict);

        if (SeedSwitch.Skip) return;

        // 3 levels: Programming -> Backend -> ASP.NET
        builder.HasData(
            new Category { Id = 1, Name = "Programming", Description = "All programming topics", ParentCategoryId = null },
            new Category { Id = 2, Name = "Backend", Description = "Server-side development", ParentCategoryId = 1 },
            new Category { Id = 3, Name = "ASP.NET", Description = "ASP.NET Core development", ParentCategoryId = 2 },
            new Category { Id = 4, Name = "Frontend", Description = "Client-side development", ParentCategoryId = 1 },
            new Category { Id = 5, Name = "Design", Description = "Design topics", ParentCategoryId = null },
            new Category { Id = 6, Name = "UI/UX", Description = null, ParentCategoryId = 5 }
        );
    }
}

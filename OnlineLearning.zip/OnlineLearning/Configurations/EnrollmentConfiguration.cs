using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using OnlineLearning.Models;

namespace OnlineLearning.Configurations;

public class EnrollmentConfiguration : IEntityTypeConfiguration<Enrollment>
{
    public void Configure(EntityTypeBuilder<Enrollment> builder)
    {
        // Composite key => a student can enroll in the same course only once
        builder.HasKey(e => new { e.StudentId, e.CourseId });

        builder.Property(e => e.EnrolledAt).IsRequired();
        builder.Property(e => e.ProgressPercentage).IsRequired();
        builder.Property(e => e.Status).IsRequired().HasConversion<string>().HasMaxLength(20);
        builder.Property(e => e.FinalGrade).HasPrecision(5, 2);   // nullable, e.g. 92.50

        // Business rule at database level: progress between 0 and 100
        builder.ToTable(t => t.HasCheckConstraint(
            "CK_Enrollments_Progress",
            "[ProgressPercentage] >= 0 AND [ProgressPercentage] <= 100"));

        // Cascade: deleting a student or a course also deletes its enrollments
        builder.HasOne(e => e.Student)
               .WithMany(s => s.Enrollments)
               .HasForeignKey(e => e.StudentId)
               .OnDelete(DeleteBehavior.Cascade);

        builder.HasOne(e => e.Course)
               .WithMany(c => c.Enrollments)
               .HasForeignKey(e => e.CourseId)
               .OnDelete(DeleteBehavior.Cascade);
    }
}

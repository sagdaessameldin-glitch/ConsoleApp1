using Microsoft.EntityFrameworkCore;
using OnlineLearning.Data;
using OnlineLearning.Models;

namespace OnlineLearning;

internal static class Program
{
    private static async Task Main()
    {
        await using var db = new AppDbContext();

        try
        {
            // Creates the database (if needed) and applies both migrations (model + seed data)
            await db.Database.MigrateAsync();

            // Part 02: seed from code (only when the tables are empty)
            await SeedStudentsAndEnrollmentsAsync(db);

            // ===================== CREATE =====================
            Header("CREATE 1 - Add an instructor");
            var instructorId = await AddInstructorAsync(db, "Mona Adel",
                $"mona.{Guid.NewGuid():N}"[..13] + "@learn.com", "Cloud and DevOps trainer.");

            Header("CREATE 2 - Add a course (valid, then invalid references)");
            var tempCourseId = await AddCourseAsync(db, "Temporary Course", "Used for the delete demo.",
                25.00m, CourseLevel.Beginner, instructorId, categoryId: 3, publish: true);
            await AddCourseAsync(db, "Ghost Course", null, 10m, CourseLevel.Beginner, instructorId: 999, categoryId: 3);
            await AddCourseAsync(db, "Ghost Course", null, 10m, CourseLevel.Beginner, instructorId, categoryId: 999);

            Header("CREATE 3 - Add several students (one AddRange, one SaveChanges)");
            var newStudentIds = await AddStudentsAsync(db);

            Header("CREATE 4 - Enroll a student");
            await EnrollStudentAsync(db, studentId: 1, courseId: 3);   // ok (or already enrolled on re-run)
            await EnrollStudentAsync(db, studentId: 1, courseId: 3);   // refused: already enrolled
            await EnrollStudentAsync(db, studentId: 1, courseId: 4);   // refused: course not published
            await EnrollStudentAsync(db, studentId: 999, courseId: 1); // refused: student not found
            await EnrollStudentAsync(db, studentId: 1, courseId: 999); // refused: course not found

            // ===================== READ =====================
            Header("READ 1 - Find a course");
            await FindCourseAsync(db, 1, "EF Core Deep Dive");
            await FindCourseAsync(db, 999, "Not A Real Title");

            Header("READ 2 - Filter courses by price (50 - 130), most expensive first");
            await FilterCoursesAsync(db, 50m, 130m);

            Header("READ 3 - Sub-categories and top-level categories");
            await PrintSubCategoriesAsync(db, 1);
            await PrintSubCategoriesAsync(db, 3);
            await PrintTopLevelCategoriesAsync(db);

            Header("READ 4 - Course roster (no joins)");
            await PrintCourseRosterAsync(db, 1);
            await PrintCourseRosterAsync(db, 999);

            // ===================== UPDATE =====================
            Header("UPDATE 1 - Change a price");
            await ChangePriceAsync(db, 1, 54.99m);
            await ChangePriceAsync(db, 1, -5m);
            await ChangePriceAsync(db, 999, 10m);

            Header("UPDATE 2 - Update progress");
            await UpdateProgressAsync(db, 1, 3, 55);
            await UpdateProgressAsync(db, 1, 3, 100);   // becomes Completed
            await UpdateProgressAsync(db, 1, 3, 150);   // rejected
            await UpdateProgressAsync(db, 1, 3, -1);    // rejected
            await UpdateProgressAsync(db, 999, 3, 10);  // not found

            Header("UPDATE 3 - Publish a course");
            await PublishCourseAsync(db, 5);
            await PublishCourseAsync(db, 5);   // already published
            await PublishCourseAsync(db, 999);

            // ===================== DELETE =====================
            Header("DELETE 1 - Unenroll");
            await UnenrollAsync(db, 1, 3);
            await UnenrollAsync(db, 1, 3);     // already removed -> friendly message

            Header("DELETE 2 - Delete a category (unsafe, then safe)");
            await DeleteCategoryUnsafeAsync(db, 1);   // has sub-categories -> DbUpdateException
            await DeleteCategorySafeAsync(db, 1);     // refused politely
            var leafId = await AddCategoryAsync(db, "Temporary Category", 5);
            await DeleteCategorySafeAsync(db, leafId); // leaf -> deleted

            Header("DELETE 3 - Delete a course that has enrollments");
            // Give the temporary course some enrollments first
            await EnrollStudentAsync(db, 2, tempCourseId);
            if (newStudentIds.Count > 0)
                await EnrollStudentAsync(db, newStudentIds[0], tempCourseId);
            await DeleteCourseAsync(db, tempCourseId);

            // ===================== BULK =====================
            Header("BULK 1 - Raise price of published Intermediate courses by 10%");
            await BulkRaisePriceAsync(db, CourseLevel.Intermediate);

            Header("BULK 2 - Delete all Dropped enrollments");
            await BulkDeleteDroppedAsync(db);
        }
        catch (Exception ex)
        {
            Console.WriteLine();
            Console.WriteLine($"Something went wrong: {ex.GetBaseException().Message}");
            Console.WriteLine("Check that SQL Server / LocalDB is running and the connection string in AppDbContext is correct.");
        }

        Console.WriteLine();
        Console.WriteLine("Done. Press any key to exit...");
        if (!Console.IsInputRedirected) Console.ReadKey();
    }

    private static void Header(string title)
    {
        Console.WriteLine();
        Console.WriteLine($"=== {title} ===");
    }

    // =====================================================================
    // Part 02 - Seeding from code
    // =====================================================================
    private static async Task SeedStudentsAndEnrollmentsAsync(AppDbContext db)
    {
        if (!await db.Students.AnyAsync())
        {
            db.Students.AddRange(
                new Student { FullName = "Youssef Ali", Email = "youssef.ali@mail.com", DateOfBirth = new DateTime(2001, 5, 14) },
                new Student { FullName = "Mariam Samir", Email = "mariam.samir@mail.com", DateOfBirth = new DateTime(2000, 11, 2) },
                new Student { FullName = "Karim Nabil", Email = "karim.nabil@mail.com", DateOfBirth = new DateTime(1999, 3, 27) },
                new Student { FullName = "Nour Tarek", Email = "nour.tarek@mail.com", DateOfBirth = new DateTime(2002, 8, 9) },
                new Student { FullName = "Hana Mostafa", Email = "hana.mostafa@mail.com", DateOfBirth = new DateTime(1998, 1, 30) });
            await db.SaveChangesAsync();
            Console.WriteLine("Seeded 5 students.");
        }

        if (!await db.Enrollments.AnyAsync())
        {
            // Take the real generated ids (ordered), so it works even if ids do not start at 1
            var studentIds = await db.Students.OrderBy(s => s.Id).Select(s => s.Id).Take(5).ToListAsync();
            if (studentIds.Count < 5)
            {
                Console.WriteLine("Not enough students to seed enrollments.");
                return;
            }

            var now = DateTime.UtcNow;
            db.Enrollments.AddRange(
                new Enrollment { StudentId = studentIds[0], CourseId = 1, EnrolledAt = now.AddDays(-60), ProgressPercentage = 100, Status = EnrollmentStatus.Completed, FinalGrade = 92.50m },
                new Enrollment { StudentId = studentIds[0], CourseId = 2, EnrolledAt = now.AddDays(-30), ProgressPercentage = 40, Status = EnrollmentStatus.Active },
                new Enrollment { StudentId = studentIds[1], CourseId = 1, EnrolledAt = now.AddDays(-20), ProgressPercentage = 25, Status = EnrollmentStatus.Active },
                new Enrollment { StudentId = studentIds[1], CourseId = 3, EnrolledAt = now.AddDays(-45), ProgressPercentage = 10, Status = EnrollmentStatus.Dropped },
                new Enrollment { StudentId = studentIds[2], CourseId = 2, EnrolledAt = now.AddDays(-90), ProgressPercentage = 100, Status = EnrollmentStatus.Completed, FinalGrade = 85.00m },
                new Enrollment { StudentId = studentIds[2], CourseId = 6, EnrolledAt = now.AddDays(-15), ProgressPercentage = 60, Status = EnrollmentStatus.Active },
                new Enrollment { StudentId = studentIds[3], CourseId = 3, EnrolledAt = now.AddDays(-10), ProgressPercentage = 5, Status = EnrollmentStatus.Dropped },
                new Enrollment { StudentId = studentIds[4], CourseId = 1, EnrolledAt = now.AddDays(-70), ProgressPercentage = 100, Status = EnrollmentStatus.Completed, FinalGrade = 78.00m });
            await db.SaveChangesAsync();
            Console.WriteLine("Seeded 8 enrollments.");
        }
    }

    // =====================================================================
    // CREATE
    // =====================================================================
    private static async Task<int> AddInstructorAsync(AppDbContext db, string fullName, string email, string? bio)
    {
        var instructor = new Instructor
        {
            FullName = fullName,
            Email = email,
            Bio = bio,
            JoinedAt = DateTime.UtcNow
        };

        db.Instructors.Add(instructor);
        await db.SaveChangesAsync();

        Console.WriteLine($"Instructor '{instructor.FullName}' added with Id = {instructor.Id}");
        return instructor.Id;
    }

    private static async Task<int> AddCourseAsync(AppDbContext db, string title, string? description,
        decimal price, CourseLevel level, int instructorId, int categoryId, bool publish = false)
    {
        if (string.IsNullOrWhiteSpace(title) || price <= 0)
        {
            Console.WriteLine("Invalid course data: the title is required and the price must be greater than 0.");
            return 0;
        }

        if (!await db.Instructors.AnyAsync(i => i.Id == instructorId))
        {
            Console.WriteLine($"Cannot add course: instructor {instructorId} does not exist.");
            return 0;
        }

        if (!await db.Categories.AnyAsync(c => c.Id == categoryId))
        {
            Console.WriteLine($"Cannot add course: category {categoryId} does not exist.");
            return 0;
        }

        var course = new Course
        {
            Title = title,
            Description = description,
            Price = price,
            Level = level,
            InstructorId = instructorId,
            CategoryId = categoryId,
            IsPublished = publish,
            PublishedAt = publish ? DateTime.UtcNow : null
        };

        db.Courses.Add(course);
        await db.SaveChangesAsync();

        Console.WriteLine($"Course '{course.Title}' added with Id = {course.Id} (published: {course.IsPublished})");
        return course.Id;
    }

    private static async Task<List<int>> AddStudentsAsync(AppDbContext db)
    {
        var tag = Guid.NewGuid().ToString("N")[..6];
        var students = new List<Student>
        {
            new() { FullName = "Laila Fathy",  Email = $"laila.{tag}@mail.com",  DateOfBirth = new DateTime(2003, 2, 12) },
            new() { FullName = "Adam Gamal",   Email = $"adam.{tag}@mail.com",   DateOfBirth = new DateTime(2001, 7, 21) },
            new() { FullName = "Rana Ashraf",  Email = $"rana.{tag}@mail.com",   DateOfBirth = new DateTime(2000, 12, 5) }
        };

        db.Students.AddRange(students);
        await db.SaveChangesAsync();

        foreach (var s in students)
            Console.WriteLine($"Student '{s.FullName}' added with Id = {s.Id}");

        return students.Select(s => s.Id).ToList();
    }

    private static async Task<bool> EnrollStudentAsync(AppDbContext db, int studentId, int courseId)
    {
        var student = await db.Students.FindAsync(studentId);
        if (student is null)
        {
            Console.WriteLine($"Enrollment refused: student {studentId} does not exist.");
            return false;
        }

        var course = await db.Courses.FindAsync(courseId);
        if (course is null)
        {
            Console.WriteLine($"Enrollment refused: course {courseId} does not exist.");
            return false;
        }

        if (!course.IsPublished)
        {
            Console.WriteLine($"Enrollment refused: course '{course.Title}' is not published yet.");
            return false;
        }

        if (await db.Enrollments.AnyAsync(e => e.StudentId == studentId && e.CourseId == courseId))
        {
            Console.WriteLine($"Enrollment refused: {student.FullName} is already enrolled in '{course.Title}'.");
            return false;
        }

        db.Enrollments.Add(new Enrollment
        {
            StudentId = studentId,
            CourseId = courseId,
            EnrolledAt = DateTime.UtcNow,
            ProgressPercentage = 0,
            Status = EnrollmentStatus.Active
        });
        await db.SaveChangesAsync();

        Console.WriteLine($"{student.FullName} was enrolled in '{course.Title}'.");
        return true;
    }

    // =====================================================================
    // READ
    // =====================================================================
    private static async Task FindCourseAsync(AppDbContext db, int id, string title)
    {
        var byId = await db.Courses.FindAsync(id);
        Console.WriteLine(byId is null
            ? $"Find by Id {id}: not found"
            : $"Find by Id {id}: {byId.Title} ({byId.Level}, {byId.Price:C})");

        var byTitle = await db.Courses.FirstOrDefaultAsync(c => c.Title == title);
        Console.WriteLine(byTitle is null
            ? $"Find by title '{title}': not found"
            : $"Find by title '{title}': Id = {byTitle.Id}, {byTitle.Level}, {byTitle.Price:C}");
    }

    private static async Task FilterCoursesAsync(AppDbContext db, decimal min, decimal max)
    {
        var courses = await db.Courses
            .Where(c => c.Price >= min && c.Price <= max)
            .OrderByDescending(c => c.Price)
            .Select(c => new { c.Title, c.Level, c.Price })
            .ToListAsync();

        if (courses.Count == 0)
        {
            Console.WriteLine($"No courses priced between {min} and {max}.");
            return;
        }

        foreach (var c in courses)
            Console.WriteLine($"{c.Title,-28} {c.Level,-14} {c.Price,10:F2}");
    }

    private static async Task PrintSubCategoriesAsync(AppDbContext db, int categoryId)
    {
        var parent = await db.Categories.FindAsync(categoryId);
        if (parent is null)
        {
            Console.WriteLine($"Category {categoryId} not found.");
            return;
        }

        var subs = await db.Categories
            .Where(c => c.ParentCategoryId == categoryId)
            .Select(c => c.Name)
            .ToListAsync();

        Console.WriteLine(subs.Count == 0
            ? $"'{parent.Name}' has no sub-categories."
            : $"Sub-categories of '{parent.Name}': {string.Join(", ", subs)}");
    }

    private static async Task PrintTopLevelCategoriesAsync(AppDbContext db)
    {
        var top = await db.Categories
            .Where(c => c.ParentCategoryId == null)
            .Select(c => c.Name)
            .ToListAsync();

        Console.WriteLine($"Top-level categories: {string.Join(", ", top)}");
    }

    private static async Task PrintCourseRosterAsync(AppDbContext db, int courseId)
    {
        var course = await db.Courses.FindAsync(courseId);
        if (course is null)
        {
            Console.WriteLine($"Course {courseId} not found.");
            return;
        }

        // Step 1: student ids from the enrollments
        var studentIds = await db.Enrollments
            .Where(e => e.CourseId == courseId)
            .Select(e => e.StudentId)
            .ToListAsync();

        Console.WriteLine($"'{course.Title}' has {studentIds.Count} enrolled student(s).");

        // Step 2: the students themselves, using Contains
        var names = await db.Students
            .Where(s => studentIds.Contains(s.Id))
            .Select(s => s.FullName)
            .ToListAsync();

        foreach (var name in names)
            Console.WriteLine($"  - {name}");
    }

    // =====================================================================
    // UPDATE
    // =====================================================================
    private static async Task ChangePriceAsync(AppDbContext db, int courseId, decimal newPrice)
    {
        if (newPrice <= 0)
        {
            Console.WriteLine($"Invalid price {newPrice}: it must be greater than 0.");
            return;
        }

        var course = await db.Courses.FindAsync(courseId);
        if (course is null)
        {
            Console.WriteLine($"Course {courseId} not found.");
            return;
        }

        var oldPrice = course.Price;
        course.Price = newPrice;
        await db.SaveChangesAsync();

        Console.WriteLine($"Price of '{course.Title}' changed from {oldPrice:F2} to {newPrice:F2}.");
    }

    private static async Task UpdateProgressAsync(AppDbContext db, int studentId, int courseId, int progress)
    {
        if (progress < 0 || progress > 100)
        {
            Console.WriteLine($"Invalid progress {progress}: it must be between 0 and 100.");
            return;
        }

        // Find by the composite key (StudentId, CourseId)
        var enrollment = await db.Enrollments.FindAsync(studentId, courseId);
        if (enrollment is null)
        {
            Console.WriteLine($"Enrollment (student {studentId}, course {courseId}) not found.");
            return;
        }

        enrollment.ProgressPercentage = progress;

        if (progress == 100)
            enrollment.Status = EnrollmentStatus.Completed;
        else if (enrollment.Status == EnrollmentStatus.Completed)
            enrollment.Status = EnrollmentStatus.Active;   // progress went back below 100

        await db.SaveChangesAsync();

        Console.WriteLine($"Progress of (student {studentId}, course {courseId}) is now {progress}% - status: {enrollment.Status}.");
    }

    private static async Task PublishCourseAsync(AppDbContext db, int courseId)
    {
        var course = await db.Courses.FindAsync(courseId);
        if (course is null)
        {
            Console.WriteLine($"Course {courseId} not found.");
            return;
        }

        if (course.IsPublished)
        {
            Console.WriteLine($"Course '{course.Title}' is already published (since {course.PublishedAt:yyyy-MM-dd}).");
            return;
        }

        course.IsPublished = true;
        course.PublishedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();

        Console.WriteLine($"Course '{course.Title}' published on {course.PublishedAt:yyyy-MM-dd}.");
    }

    // =====================================================================
    // DELETE
    // =====================================================================
    private static async Task UnenrollAsync(AppDbContext db, int studentId, int courseId)
    {
        var enrollment = await db.Enrollments.FindAsync(studentId, courseId);
        if (enrollment is null)
        {
            Console.WriteLine($"Enrollment (student {studentId}, course {courseId}) not found - nothing to delete.");
            return;
        }

        db.Enrollments.Remove(enrollment);
        await db.SaveChangesAsync();

        Console.WriteLine($"Student {studentId} was unenrolled from course {courseId}.");
    }

    // Tries to delete directly: the Restrict delete behavior makes SQL Server reject it.
    private static async Task DeleteCategoryUnsafeAsync(AppDbContext db, int categoryId)
    {
        var category = await db.Categories.FindAsync(categoryId);
        if (category is null)
        {
            Console.WriteLine($"Category {categoryId} not found.");
            return;
        }

        try
        {
            db.Categories.Remove(category);
            await db.SaveChangesAsync();
            Console.WriteLine($"Category '{category.Name}' deleted.");
        }
        catch (DbUpdateException ex)
        {
            Console.WriteLine($"[Unsafe delete failed] {ex.Message}");
            if (ex.InnerException is not null)
                Console.WriteLine($"  Inner: {ex.InnerException.Message}");

            // Forget the failed change so the context stays usable
            db.ChangeTracker.Clear();
        }
    }

    // Checks for sub-categories (and courses) before deleting.
    private static async Task DeleteCategorySafeAsync(AppDbContext db, int categoryId)
    {
        var category = await db.Categories.FindAsync(categoryId);
        if (category is null)
        {
            Console.WriteLine($"Category {categoryId} not found.");
            return;
        }

        if (await db.Categories.AnyAsync(c => c.ParentCategoryId == categoryId))
        {
            Console.WriteLine($"Cannot delete '{category.Name}': it still has sub-categories.");
            return;
        }

        if (await db.Courses.AnyAsync(c => c.CategoryId == categoryId))
        {
            Console.WriteLine($"Cannot delete '{category.Name}': it still has courses.");
            return;
        }

        db.Categories.Remove(category);
        await db.SaveChangesAsync();
        Console.WriteLine($"Category '{category.Name}' deleted safely.");
    }

    private static async Task<int> AddCategoryAsync(AppDbContext db, string name, int? parentId)
    {
        var category = new Category { Name = name, ParentCategoryId = parentId };
        db.Categories.Add(category);
        await db.SaveChangesAsync();
        Console.WriteLine($"Category '{name}' added with Id = {category.Id}");
        return category.Id;
    }

    private static async Task DeleteCourseAsync(AppDbContext db, int courseId)
    {
        var course = await db.Courses.FindAsync(courseId);
        if (course is null)
        {
            Console.WriteLine($"Course {courseId} not found.");
            return;
        }

        var before = await db.Enrollments.CountAsync(e => e.CourseId == courseId);
        Console.WriteLine($"Enrollments of '{course.Title}' before delete: {before}");

        db.Courses.Remove(course);
        await db.SaveChangesAsync();

        var after = await db.Enrollments.CountAsync(e => e.CourseId == courseId);
        Console.WriteLine($"Enrollments of '{course.Title}' after delete: {after}");

        // Why were the enrollments removed?
        // In EnrollmentConfiguration the relationship Course -> Enrollments is configured with
        // OnDelete(DeleteBehavior.Cascade). The foreign key in the database is created with
        // ON DELETE CASCADE, so when the course row is deleted SQL Server deletes every
        // enrollment that references it automatically (we never loaded them in memory).
    }

    // =====================================================================
    // BULK OPERATIONS (single SQL statement, entities are not loaded)
    // =====================================================================
    private static async Task BulkRaisePriceAsync(AppDbContext db, CourseLevel level)
    {
        var affected = await db.Courses
            .Where(c => c.IsPublished && c.Level == level)
            .ExecuteUpdateAsync(s => s.SetProperty(c => c.Price, c => c.Price * 1.10m));

        Console.WriteLine($"Price raised by 10% for published {level} courses. Affected rows: {affected}");
    }

    private static async Task BulkDeleteDroppedAsync(AppDbContext db)
    {
        var affected = await db.Enrollments
            .Where(e => e.Status == EnrollmentStatus.Dropped)
            .ExecuteDeleteAsync();

        Console.WriteLine($"Dropped enrollments deleted. Affected rows: {affected}");
    }
}

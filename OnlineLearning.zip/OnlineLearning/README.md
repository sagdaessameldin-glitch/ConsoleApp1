# Online Learning Platform - EF Core Code-First (Session 03)

Requirements: .NET 8 SDK, SQL Server or LocalDB, and the EF tool:
    dotnet tool install --global dotnet-ef

## Creating the two migrations (model first, then seed data)

The HasData calls are inside the configuration classes. Setting SKIP_SEED=1 hides them,
so the first migration contains only the schema.

PowerShell:
    $env:SKIP_SEED = "1"
    dotnet ef migrations add InitialModel
    Remove-Item Env:SKIP_SEED
    dotnet ef migrations add SeedData

CMD:
    set SKIP_SEED=1
    dotnet ef migrations add InitialModel
    set SKIP_SEED=
    dotnet ef migrations add SeedData

(If you prefer, you can instead comment out the three `builder.HasData(...)` blocks, add
InitialModel, un-comment them, and add SeedData.)

Then run:
    dotnet run
The app applies the migrations itself (MigrateAsync) - or run `dotnet ef database update`.
Running the app twice does not duplicate the students / enrollments.

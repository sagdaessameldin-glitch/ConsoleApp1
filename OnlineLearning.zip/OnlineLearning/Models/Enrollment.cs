namespace OnlineLearning.Models;

// Join entity (Student <-> Course) with payload. Composite key: (StudentId, CourseId)
public class Enrollment
{
    public int StudentId { get; set; }
    public Student Student { get; set; } = null!;

    public int CourseId { get; set; }
    public Course Course { get; set; } = null!;

    public DateTime EnrolledAt { get; set; }
    public int ProgressPercentage { get; set; }
    public EnrollmentStatus Status { get; set; }

    // Given only when the course is completed
    public decimal? FinalGrade { get; set; }
}

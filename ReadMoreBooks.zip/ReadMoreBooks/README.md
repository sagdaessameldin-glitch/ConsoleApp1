# ReadMore Books - EF Core (Conventions Only)

## التشغيل
```
cd ReadMoreBooks
dotnet restore
dotnet run
```
المطلوب: .NET 8 SDK + SQL Server (LocalDB أو Express). لو غيّرت السيرفر عدّل الـ Connection String في Data/BookstoreContext.cs

## بديل Migrations (بدل EnsureCreated)
احذف سطري EnsureDeleted/EnsureCreated من Program.cs ثم:
```
dotnet tool install --global dotnet-ef
dotnet ef migrations add InitialCreate
dotnet ef database update
```

using Microsoft.EntityFrameworkCore;
using ReadMoreBooks.Data;
using ReadMoreBooks.Models;

using var context = new BookstoreContext();

// إنشاء الداتا بيز من الـ Conventions (من الصفر كل مرة)
context.Database.EnsureDeleted();
context.Database.EnsureCreated();
Console.WriteLine($"Database created. Can connect: {context.Database.CanConnect()}\n");

// بيانات تجريبية
var orwell = new Author
{
    FirstName = "George", LastName = "Orwell", Email = "george@example.com",
    Biography = "English novelist and essayist.", DateOfBirth = new DateTime(1903, 6, 25)
};
var christie = new Author
{
    FirstName = "Agatha", LastName = "Christie", Email = "agatha@example.com",
    Biography = "Queen of crime fiction.", DateOfBirth = new DateTime(1890, 9, 15)
};
var fiction = new Category { Name = "Fiction", Description = "Novels and stories", IsActive = true };
var mystery = new Category { Name = "Mystery", Description = "Detective stories", IsActive = true };

context.Books.AddRange(
    new Book { Title = "1984", ISBN = "9780451524935", Price = 12.99m, NumberOfPages = 328, PublishedYear = 1949, InStock = true, Author = orwell, Category = fiction },
    new Book { Title = "Animal Farm", ISBN = "9780451526342", Price = 9.99m, NumberOfPages = 112, PublishedYear = 1945, InStock = false, Author = orwell, Category = fiction },
    new Book { Title = "Murder on the Orient Express", ISBN = "9780062693662", Price = 14.50m, NumberOfPages = 256, PublishedYear = 1934, InStock = true, Author = christie, Category = mystery }
);
context.SaveChanges();
Console.WriteLine("Sample data saved.\n");

// 1) عرض البيانات مع العلاقات
Console.WriteLine("=== Books ===");
foreach (var b in context.Books.Include(b => b.Author).Include(b => b.Category))
{
    Console.WriteLine($"{b.Title} | {b.ISBN} | ${b.Price} | {b.NumberOfPages} pages | {b.PublishedYear} | " +
                      $"InStock: {b.InStock} | {b.Author.FirstName} {b.Author.LastName} | {b.Category.Name}");
}

// 2) إثبات شكل الجداول والأعمدة اللي اتعملت في SQL Server
Console.WriteLine("\n=== Database Schema ===");
var conn = context.Database.GetDbConnection();
conn.Open();
using var cmd = conn.CreateCommand();
cmd.CommandText = @"SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE, IS_NULLABLE
                    FROM INFORMATION_SCHEMA.COLUMNS
                    ORDER BY TABLE_NAME, ORDINAL_POSITION";
using var reader = cmd.ExecuteReader();
string current = "";
while (reader.Read())
{
    var table = reader.GetString(0);
    if (table != current) { Console.WriteLine($"\n[{table}]"); current = table; }
    Console.WriteLine($"  {reader.GetString(1),-15} {reader.GetString(2),-10} Nullable: {reader.GetString(3)}");
}

/* =========================================================
   Gym Management System - SQL Server schema (core tables)
   Matches the EF Core model in the GymManagement project.
   Run this script FIRST, then start the app (it connects to this database).
   ========================================================= */
IF DB_ID('GymManagementDb') IS NULL CREATE DATABASE GymManagementDb;
GO
USE GymManagementDb;
GO

/* ---------- Plans ---------- */
CREATE TABLE Plans (
    Id           INT IDENTITY(1,1) PRIMARY KEY,
    Name         NVARCHAR(50)   NOT NULL,
    Description  NVARCHAR(500)  NOT NULL,
    DurationDays INT            NOT NULL,
    Price        DECIMAL(10,2)  NOT NULL,
    IsActive     BIT            NOT NULL DEFAULT 1,
    CONSTRAINT CK_Plans_DurationDays CHECK (DurationDays BETWEEN 1 AND 365),
    CONSTRAINT UQ_Plans_Name UNIQUE (Name)
);

/* ---------- Members ---------- */
CREATE TABLE Members (
    Id                     INT IDENTITY(1,1) PRIMARY KEY,
    Name                   VARCHAR(50)  NOT NULL,
    Email                  VARCHAR(100) NOT NULL,
    Phone                  VARCHAR(11)  NOT NULL,
    DateOfBirth            DATETIME2    NOT NULL,
    Gender                 INT          NOT NULL,          -- 1 = Male, 2 = Female
    Address_BuildingNumber VARCHAR(20)  NOT NULL,
    Address_Street         VARCHAR(100) NOT NULL,
    Address_City           VARCHAR(50)  NOT NULL,
    JoinDate               DATETIME2    NOT NULL DEFAULT GETDATE(),
    Photo                  VARCHAR(200) NULL,
    CONSTRAINT UQ_Members_Email UNIQUE (Email),
    CONSTRAINT UQ_Members_Phone UNIQUE (Phone),
    CONSTRAINT CK_Members_Phone CHECK (Phone LIKE '01[0125][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

/* ---------- Trainers ---------- */
CREATE TABLE Trainers (
    Id                     INT IDENTITY(1,1) PRIMARY KEY,
    Name                   VARCHAR(50)  NOT NULL,
    Email                  VARCHAR(100) NOT NULL,
    Phone                  VARCHAR(11)  NOT NULL,
    DateOfBirth            DATETIME2    NOT NULL,
    Gender                 INT          NOT NULL,
    Address_BuildingNumber VARCHAR(20)  NOT NULL,
    Address_Street         VARCHAR(100) NOT NULL,
    Address_City           VARCHAR(50)  NOT NULL,
    HireDate               DATETIME2    NOT NULL DEFAULT GETDATE(),
    Speciality             VARCHAR(50)  NOT NULL,
    CONSTRAINT UQ_Trainers_Email UNIQUE (Email),
    CONSTRAINT UQ_Trainers_Phone UNIQUE (Phone),
    CONSTRAINT CK_Trainers_Phone CHECK (Phone LIKE '01[0125][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
);

/* ---------- Sessions ---------- */
CREATE TABLE Sessions (
    Id          INT IDENTITY(1,1) PRIMARY KEY,
    Description NVARCHAR(500) NOT NULL,
    Capacity    INT           NOT NULL,
    StartDate   DATETIME2     NOT NULL,
    EndDate     DATETIME2     NOT NULL,
    TrainerId   INT           NOT NULL,
    CONSTRAINT FK_Sessions_Trainers FOREIGN KEY (TrainerId) REFERENCES Trainers(Id) ON DELETE CASCADE,
    CONSTRAINT CK_Sessions_Capacity CHECK (Capacity BETWEEN 1 AND 25),
    CONSTRAINT CK_Sessions_EndAfterStart CHECK (EndDate > StartDate)
);
CREATE INDEX IX_Sessions_TrainerId ON Sessions(TrainerId);

/* ---------- MemberPlans (memberships) ---------- */
CREATE TABLE MemberPlans (
    Id        INT IDENTITY(1,1) PRIMARY KEY,
    MemberId  INT       NOT NULL,
    PlanId    INT       NOT NULL,
    StartDate DATETIME2 NOT NULL DEFAULT GETDATE(),
    EndDate   DATETIME2 NOT NULL,                 -- StartDate + Plan.DurationDays (set by the app)
    CONSTRAINT FK_MemberPlans_Members FOREIGN KEY (MemberId) REFERENCES Members(Id) ON DELETE CASCADE,
    CONSTRAINT FK_MemberPlans_Plans   FOREIGN KEY (PlanId)   REFERENCES Plans(Id)   ON DELETE NO ACTION
);
CREATE INDEX IX_MemberPlans_MemberId ON MemberPlans(MemberId);
CREATE INDEX IX_MemberPlans_PlanId   ON MemberPlans(PlanId);
GO


/* =========================================================
   ASP.NET Core Identity tables (Login / Sign out)
   ========================================================= */
CREATE TABLE AspNetRoles (
    Id               NVARCHAR(450) NOT NULL PRIMARY KEY,
    Name             NVARCHAR(256) NULL,
    NormalizedName   NVARCHAR(256) NULL,
    ConcurrencyStamp NVARCHAR(MAX) NULL
);
CREATE UNIQUE INDEX RoleNameIndex ON AspNetRoles(NormalizedName) WHERE NormalizedName IS NOT NULL;

CREATE TABLE AspNetUsers (
    Id                   NVARCHAR(450)  NOT NULL PRIMARY KEY,
    FullName             NVARCHAR(MAX)  NULL,
    UserName             NVARCHAR(256)  NULL,
    NormalizedUserName   NVARCHAR(256)  NULL,
    Email                NVARCHAR(256)  NULL,
    NormalizedEmail      NVARCHAR(256)  NULL,
    EmailConfirmed       BIT            NOT NULL,
    PasswordHash         NVARCHAR(MAX)  NULL,
    SecurityStamp        NVARCHAR(MAX)  NULL,
    ConcurrencyStamp     NVARCHAR(MAX)  NULL,
    PhoneNumber          NVARCHAR(MAX)  NULL,
    PhoneNumberConfirmed BIT            NOT NULL,
    TwoFactorEnabled     BIT            NOT NULL,
    LockoutEnd           DATETIMEOFFSET NULL,
    LockoutEnabled       BIT            NOT NULL,
    AccessFailedCount    INT            NOT NULL
);
CREATE INDEX EmailIndex ON AspNetUsers(NormalizedEmail);
CREATE UNIQUE INDEX UserNameIndex ON AspNetUsers(NormalizedUserName) WHERE NormalizedUserName IS NOT NULL;

CREATE TABLE AspNetRoleClaims (
    Id         INT IDENTITY(1,1) PRIMARY KEY,
    RoleId     NVARCHAR(450) NOT NULL,
    ClaimType  NVARCHAR(MAX) NULL,
    ClaimValue NVARCHAR(MAX) NULL,
    CONSTRAINT FK_AspNetRoleClaims_AspNetRoles_RoleId FOREIGN KEY (RoleId) REFERENCES AspNetRoles(Id) ON DELETE CASCADE
);
CREATE INDEX IX_AspNetRoleClaims_RoleId ON AspNetRoleClaims(RoleId);

CREATE TABLE AspNetUserClaims (
    Id         INT IDENTITY(1,1) PRIMARY KEY,
    UserId     NVARCHAR(450) NOT NULL,
    ClaimType  NVARCHAR(MAX) NULL,
    ClaimValue NVARCHAR(MAX) NULL,
    CONSTRAINT FK_AspNetUserClaims_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE
);
CREATE INDEX IX_AspNetUserClaims_UserId ON AspNetUserClaims(UserId);

CREATE TABLE AspNetUserLogins (
    LoginProvider       NVARCHAR(450) NOT NULL,
    ProviderKey         NVARCHAR(450) NOT NULL,
    ProviderDisplayName NVARCHAR(MAX) NULL,
    UserId              NVARCHAR(450) NOT NULL,
    CONSTRAINT PK_AspNetUserLogins PRIMARY KEY (LoginProvider, ProviderKey),
    CONSTRAINT FK_AspNetUserLogins_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE
);
CREATE INDEX IX_AspNetUserLogins_UserId ON AspNetUserLogins(UserId);

CREATE TABLE AspNetUserRoles (
    UserId NVARCHAR(450) NOT NULL,
    RoleId NVARCHAR(450) NOT NULL,
    CONSTRAINT PK_AspNetUserRoles PRIMARY KEY (UserId, RoleId),
    CONSTRAINT FK_AspNetUserRoles_AspNetRoles_RoleId FOREIGN KEY (RoleId) REFERENCES AspNetRoles(Id) ON DELETE CASCADE,
    CONSTRAINT FK_AspNetUserRoles_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE
);
CREATE INDEX IX_AspNetUserRoles_RoleId ON AspNetUserRoles(RoleId);

CREATE TABLE AspNetUserTokens (
    UserId        NVARCHAR(450) NOT NULL,
    LoginProvider NVARCHAR(450) NOT NULL,
    Name          NVARCHAR(450) NOT NULL,
    Value         NVARCHAR(MAX) NULL,
    CONSTRAINT PK_AspNetUserTokens PRIMARY KEY (UserId, LoginProvider, Name),
    CONSTRAINT FK_AspNetUserTokens_AspNetUsers_UserId FOREIGN KEY (UserId) REFERENCES AspNetUsers(Id) ON DELETE CASCADE
);
GO

/* The admin account (admin@gym.com / Admin@123) is created by the app on first run,
   because Identity must generate the password hash itself. */

/* ---------- Sample plans ---------- */
INSERT INTO Plans (Name, Description, DurationDays, Price, IsActive) VALUES
('Basic Monthly',      'Full gym floor access during staffed hours.',          30,  700,  1),
('Standard Quarterly', 'Gym floor + group classes, one free PT session.',      90,  1800, 1),
('Premium Half-Year',  'Unlimited classes, locker and a monthly body scan.',   180, 3200, 1),
('Annual Elite',       'Everything included, 4 PT sessions and guest passes.', 365, 5500, 1),
('Student Monthly',    'Off-peak access for students with a valid ID.',        30,  450,  0);
GO

/* Membership status is computed, not stored:
   SELECT *, CASE WHEN EndDate > GETDATE() THEN 'Active' ELSE 'Expired' END AS Status FROM MemberPlans; */

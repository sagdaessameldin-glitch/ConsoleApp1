using Microsoft.EntityFrameworkCore;

namespace NationalBank;

public class BankContext : DbContext
{
    public DbSet<Branch> Branches => Set<Branch>();
    public DbSet<Manager> Managers => Set<Manager>();
    public DbSet<Customer> Customers => Set<Customer>();
    public DbSet<Account> Accounts => Set<Account>();
    public DbSet<CustomerAccount> CustomerAccounts => Set<CustomerAccount>();
    public DbSet<Transaction> Transactions => Set<Transaction>();

    protected override void OnConfiguring(DbContextOptionsBuilder options)
        => options.UseSqlServer(
            "Server=(localdb)\\MSSQLLocalDB;Database=NationalBankDb;Trusted_Connection=True;TrustServerCertificate=True;");

    protected override void OnModelCreating(ModelBuilder mb)
    {
        // ---- Manager ----
        mb.Entity<Manager>(e =>
        {
            e.Property(x => x.FullName).HasMaxLength(100).IsRequired();
            e.Property(x => x.Email).HasMaxLength(150).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsRequired();
        });

        // ---- Branch (1:1 with Manager) ----
        mb.Entity<Branch>(e =>
        {
            e.HasKey(x => x.Code);
            e.Property(x => x.Code).HasMaxLength(10);
            e.Property(x => x.Name).HasMaxLength(100).IsRequired();
            e.Property(x => x.Address).HasMaxLength(250).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsRequired();

            e.HasOne(b => b.Manager)
             .WithOne(m => m.Branch)
             .HasForeignKey<Branch>(b => b.ManagerId)
             .OnDelete(DeleteBehavior.Restrict);
        });

        // ---- Customer ----
        mb.Entity<Customer>(e =>
        {
            e.Property(x => x.FullName).HasMaxLength(100).IsRequired();
            e.Property(x => x.NationalId).HasMaxLength(20).IsRequired();
            e.HasIndex(x => x.NationalId).IsUnique();
            e.Property(x => x.Email).HasMaxLength(150).IsRequired();
            e.Property(x => x.PhoneNumber).HasMaxLength(20).IsRequired();
            e.Property(x => x.Address).HasMaxLength(250).IsRequired();
            e.Property(x => x.DateOfBirth).HasColumnType("date");
            e.Property(x => x.CustomerType).HasConversion<string>().HasMaxLength(20);
        });

        // ---- Account (M:1 Branch) ----
        mb.Entity<Account>(e =>
        {
            e.HasKey(x => x.AccountNumber);
            e.Property(x => x.AccountNumber).HasMaxLength(20);
            e.Property(x => x.CurrentBalance).HasColumnType("decimal(18,2)");
            e.Property(x => x.AccountType).HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.BranchCode).HasMaxLength(10);

            e.HasOne(a => a.Branch)
             .WithMany(b => b.Accounts)
             .HasForeignKey(a => a.BranchCode)
             .OnDelete(DeleteBehavior.Restrict);
        });

        // ---- CustomerAccount (M:N "Have") ----
        mb.Entity<CustomerAccount>(e =>
        {
            e.HasKey(x => new { x.CustomerId, x.AccountNumber });
            e.Property(x => x.AccountNumber).HasMaxLength(20);
            e.Property(x => x.OwnershipType).HasConversion<string>().HasMaxLength(20);
            e.Property(x => x.AccountStatus).HasConversion<string>().HasMaxLength(20);

            e.HasOne(ca => ca.Customer)
             .WithMany(c => c.CustomerAccounts)
             .HasForeignKey(ca => ca.CustomerId)
             .OnDelete(DeleteBehavior.Cascade);

            e.HasOne(ca => ca.Account)
             .WithMany(a => a.CustomerAccounts)
             .HasForeignKey(ca => ca.AccountNumber)
             .OnDelete(DeleteBehavior.Cascade);
        });

        // ---- Transaction (M:1 Account) ----
        mb.Entity<Transaction>(e =>
        {
            e.HasKey(x => x.TransactionNumber);
            e.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            e.Property(x => x.Note).HasMaxLength(250);
            e.Property(x => x.AccountNumber).HasMaxLength(20);
            e.Property(x => x.TransactionType).HasConversion<string>().HasMaxLength(20);

            e.HasOne(t => t.Account)
             .WithMany(a => a.Transactions)
             .HasForeignKey(t => t.AccountNumber)
             .OnDelete(DeleteBehavior.Restrict);   // never lose financial history silently
        });

        // ---- Seeding ----
        mb.Entity<Manager>().HasData(
            new Manager { Id = 1, FullName = "Khaled Mansour", Email = "khaled.mansour@nationalbank.com", PhoneNumber = "01001112222", HireDate = new DateTime(2015, 3, 1) },
            new Manager { Id = 2, FullName = "Sara Hassan",    Email = "sara.hassan@nationalbank.com",    PhoneNumber = "01113334444", HireDate = new DateTime(2018, 9, 15) });

        mb.Entity<Branch>().HasData(
            new Branch { Code = "CAI-01", Name = "Cairo Main Branch", Address = "1 Tahrir Square, Cairo",  PhoneNumber = "0225550001", ManagerId = 1 },
            new Branch { Code = "ALX-01", Name = "Alexandria Branch", Address = "25 Corniche Rd, Alexandria", PhoneNumber = "0345550002", ManagerId = 2 });
    }
}

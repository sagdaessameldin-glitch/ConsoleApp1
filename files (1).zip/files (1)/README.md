# National Bank – EF Core Code-First

## Run
```
dotnet tool install --global dotnet-ef      # once
dotnet restore
dotnet ef migrations add InitialCreate
dotnet ef database update
dotnet run
```
Connection string is in `BankContext.OnConfiguring` (default: LocalDB).

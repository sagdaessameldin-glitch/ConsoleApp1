using System.Net.Mail;
using System.Text.RegularExpressions;
using Microsoft.EntityFrameworkCore;

namespace NationalBank;

internal static class Program
{
    private static void Main()
    {
        using var db = new BankContext();
        db.Database.Migrate();   // applies migrations (+ seed data)

        while (true)
        {
            ShowMenu();
            var choice = Console.ReadLine()?.Trim();
            Console.WriteLine();
            try
            {
                switch (choice)
                {
                    case "1": AddCustomer(db); break;
                    case "2": OpenAccount(db); break;
                    case "3": UpdateStatus(db); break;
                    case "4": RemoveAccount(db); break;
                    case "5": ListCustomers(db); break;
                    case "0":
                        db.Dispose();
                        Console.WriteLine("Goodbye!");
                        return;
                    default: Error("Invalid choice, please pick a number from the menu."); break;
                }
            }
            catch (Exception ex)   // last line of defence – the app must never crash
            {
                Error($"Unexpected error: {ex.InnerException?.Message ?? ex.Message}");
            }
            Pause();
        }
    }

    // ───────────────────────── Menu actions ─────────────────────────

    private static void AddCustomer(BankContext db)
    {
        Console.WriteLine("--- Add New Customer ---");
        var name = ReadString("Full Name      : ", s => s.Length >= 3, "Name must be at least 3 characters.");
        var nid = ReadString("National ID    : ", s => Regex.IsMatch(s, @"^\d{14}$"), "National ID must be exactly 14 digits.");
        if (db.Customers.Any(c => c.NationalId == nid))
        {
            Error("A customer with this National ID already exists.");
            return;
        }
        var dob = ReadDate("Date of Birth  : (yyyy-MM-dd) ");
        var email = ReadString("Email          : ", IsValidEmail, "Invalid email format.");
        var phone = ReadString("Phone          : ", s => Regex.IsMatch(s, @"^\+?\d{8,15}$"), "Phone must be 8-15 digits.");
        var address = ReadString("Address        : ", s => s.Length >= 5, "Address is too short.");
        var type = ReadEnum<CustomerType>("Customer Type:");

        var customer = new Customer
        {
            FullName = name, NationalId = nid, DateOfBirth = dob,
            Email = email, PhoneNumber = phone, Address = address, CustomerType = type
        };
        db.Customers.Add(customer);
        db.SaveChanges();
        Success($"Customer created successfully. CustomerId = {customer.Id}");
    }

    private static void OpenAccount(BankContext db)
    {
        Console.WriteLine("--- Open New Account ---");
        var accNo = ReadString("Account Number : ", s => Regex.IsMatch(s, @"^[A-Za-z0-9\-]{3,20}$"), "Use 3-20 letters/digits/dashes.");
        var accType = ReadEnum<AccountType>("Account Type:");
        var branchCode = ReadString("Branch Code    : ", s => s.Length > 0, "Required.").ToUpper();
        var customerId = ReadInt("Customer Id    : ");
        var role = ReadEnum<OwnershipType>("Ownership Role:");

        Info($"Validating branch '{branchCode}' and customer #{customerId}...");
        if (!db.Branches.Any(b => b.Code == branchCode)) { Error($"Branch '{branchCode}' does not exist."); return; }
        if (!db.Customers.Any(c => c.Id == customerId)) { Error($"Customer #{customerId} does not exist."); return; }

        var account = db.Accounts.Include(a => a.CustomerAccounts).FirstOrDefault(a => a.AccountNumber == accNo);
        if (account is null)
        {
            account = new Account
            {
                AccountNumber = accNo, AccountType = accType, BranchCode = branchCode,
                OpeningDate = DateTime.Today, CurrentBalance = 0m
            };
            db.Accounts.Add(account);
        }
        else
        {
            // Joint account scenario: the account already exists, we only add another owner
            if (account.BranchCode != branchCode || account.AccountType != accType)
            { Error("Account already exists with different branch/type."); return; }
            if (account.CustomerAccounts.Any(ca => ca.CustomerId == customerId))
            { Error("This customer already owns this account."); return; }
            if (role == OwnershipType.Primary && account.CustomerAccounts.Any(ca => ca.OwnershipType == OwnershipType.Primary))
            { Error("This account already has a Primary owner."); return; }
        }

        account.CustomerAccounts.Add(new CustomerAccount
        {
            CustomerId = customerId, OwnershipType = role,
            OwnershipStartDate = DateTime.Today, AccountStatus = AccountStatus.Active
        });
        db.SaveChanges();
        Success($"Account '{accNo}' created and linked to customer {customerId} as {role} owner.");
    }

    private static void UpdateStatus(BankContext db)
    {
        Console.WriteLine("--- Update Account Status ---");
        var accNo = ReadString("Account Number : ", s => s.Length > 0, "Required.");
        var customerId = ReadInt("Customer Id    : ");

        var link = db.CustomerAccounts.Find(customerId, accNo);
        if (link is null) { Error("No ownership link found for this account/customer."); return; }

        var status = ReadEnum<AccountStatus>("New Status:");
        link.AccountStatus = status;
        db.SaveChanges();
        Success($"Status updated to {status}.");
    }

    private static void RemoveAccount(BankContext db)
    {
        Console.WriteLine("--- Remove Account From Customer ---");
        var accNo = ReadString("Account Number : ", s => s.Length > 0, "Required.");
        var customerId = ReadInt("Customer Id    : ");

        var link = db.CustomerAccounts.Include(ca => ca.Account).ThenInclude(a => a.CustomerAccounts)
                     .Include(ca => ca.Account).ThenInclude(a => a.Transactions)
                     .FirstOrDefault(ca => ca.CustomerId == customerId && ca.AccountNumber == accNo);
        if (link is null) { Error("No ownership link found for this account/customer."); return; }

        var account = link.Account;
        db.CustomerAccounts.Remove(link);
        Console.WriteLine();
        Success("  Ownership link deleted.");

        bool lastOwner = account.CustomerAccounts.Count == 1;
        if (lastOwner)
        {
            if (account.Transactions.Any())
                Info($"      That was the last owner, but account '{accNo}' has transaction history so it was kept.");
            else
            {
                db.Accounts.Remove(account);
                Info($"      That was the last owner - account '{accNo}' was also removed.");
            }
        }
        db.SaveChanges();
    }

    private static void ListCustomers(BankContext db)
    {
        // Eager loading: Customer -> CustomerAccounts -> Account -> Branch in a single query
        var customers = db.Customers
            .Include(c => c.CustomerAccounts).ThenInclude(ca => ca.Account).ThenInclude(a => a.Branch)
            .AsNoTracking()
            .OrderBy(c => c.Id)
            .ToList();

        Console.WriteLine("--- All Customers ---\n");
        if (customers.Count == 0) { Console.WriteLine("  (no customers)"); return; }

        foreach (var c in customers)
        {
            Console.WriteLine($"  #{c.Id} {c.FullName} ({c.CustomerType})");
            if (c.CustomerAccounts.Count == 0) { Console.WriteLine("      (no accounts)"); continue; }
            foreach (var ca in c.CustomerAccounts)
            {
                var a = ca.Account;
                Console.WriteLine($"      {a.AccountNumber,-10} {a.AccountType,-9} Balance: {a.CurrentBalance,12:N2}   " +
                                  $"{ca.OwnershipType,-9} {ca.AccountStatus,-7} @ {a.Branch.Name}");
            }
        }
    }

    // ───────────────────────── UI helpers ─────────────────────────

    private static void ShowMenu()
    {
        Console.Clear();
        Console.WriteLine("========================================");
        Console.WriteLine("   National Bank - Management");
        Console.WriteLine("========================================");
        Console.WriteLine("  1) Add a new Customer");
        Console.WriteLine("  2) Open a new Account for a Customer");
        Console.WriteLine("  3) Update Account Status (Active / Closed)");
        Console.WriteLine("  4) Remove an Account from a Customer");
        Console.WriteLine("  5) List all Customers (with accounts)");
        Console.WriteLine("  0) Exit");
        Console.WriteLine("----------------------------------------");
        Console.Write("  Enter choice: ");
    }

    private static void Pause()
    {
        Console.WriteLine("\nPress any key to return to the menu...");
        Console.ReadKey(true);
    }

    private static void Color(string msg, ConsoleColor c)
    {
        var old = Console.ForegroundColor;
        Console.ForegroundColor = c;
        Console.WriteLine(msg);
        Console.ForegroundColor = old;
    }
    private static void Success(string m) => Color(m, ConsoleColor.Green);
    private static void Error(string m) => Color(m, ConsoleColor.Red);
    private static void Info(string m) => Color(m, ConsoleColor.Cyan);

    // ───────────────────────── Input helpers ─────────────────────────

    private static string ReadString(string prompt, Func<string, bool> isValid, string errorMsg)
    {
        while (true)
        {
            Console.Write(prompt);
            var s = Console.ReadLine()?.Trim() ?? "";
            if (isValid(s)) return s;
            Error("  " + errorMsg);
        }
    }

    private static int ReadInt(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            if (int.TryParse(Console.ReadLine(), out var n) && n > 0) return n;
            Error("  Please enter a valid positive number.");
        }
    }

    private static DateTime ReadDate(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            if (DateTime.TryParseExact(Console.ReadLine()?.Trim(), "yyyy-MM-dd",
                    System.Globalization.CultureInfo.InvariantCulture,
                    System.Globalization.DateTimeStyles.None, out var d))
            {
                if (d > DateTime.Today) { Error("  Date of birth can't be in the future."); continue; }
                if (d.AddYears(18) > DateTime.Today) { Error("  Customer must be at least 18 years old."); continue; }
                return d;
            }
            Error("  Invalid date. Use the format yyyy-MM-dd.");
        }
    }

    private static T ReadEnum<T>(string title) where T : struct, Enum
    {
        var values = Enum.GetValues<T>();
        Console.WriteLine(title);
        foreach (var v in values) Console.WriteLine($"    {Convert.ToInt32(v)}) {v}");
        while (true)
        {
            Console.Write("  Choice: ");
            if (int.TryParse(Console.ReadLine(), out var n) && Enum.IsDefined(typeof(T), n))
                return (T)Enum.ToObject(typeof(T), n);
            Error("  Invalid choice, try again.");
        }
    }

    private static bool IsValidEmail(string s)
    {
        try { return new MailAddress(s).Address == s && s.Contains('.'); }
        catch { return false; }
    }
}
